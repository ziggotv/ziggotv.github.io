"""
module containing classes for recordings
"""
import dataclasses
from enum import IntEnum
import json
import os
import datetime

import xbmcaddon
import xbmcvfs

from resources.lib import utils
from resources.lib.globals import G


@dataclasses.dataclass
class Poster:
    """
    Small data class to store the poster
    """

    def __init__(self, posterJson):
        self.url = posterJson['url']
        self.type = posterJson['type']  # values seen: HighResPortrait



class RecordingType(IntEnum):
    """
    Enum for the service status
    """
    PLANNED = 1
    RECORDED = 2

class Recording:
    """
    class to store all the data for a recording. Is used as a base class for others.
    """

    # pylint: disable=too-many-instance-attributes
    @dataclasses.dataclass
    class Language:
        """
        small class to store the data for a language
        """

        def __init__(self, languageJson):
            self.language = languageJson['lang']
            self.purpose = languageJson['purpose']

    def __init__(self, recordingJson):
        # pylint: disable=too-many-branches, too-many-statements
        if 'poster' in recordingJson:
            self.poster = Poster(posterJson=recordingJson['poster'])
        else:
            self.poster = None
        self.recordingState = recordingJson['recordingState']  # recorded, planned
        self.minimumAge = 0
        self.private = False
        self.isAdult = False
        self.diskSpace = 0
        self.expirationDate = ''
        self.technicalDuration = 0
        self.isOttBlackout = False
        self.duration = 0
        self.bookmark = 0
        self.subtitles = []
        self.seasonNumber = None
        self.episodeNumber = None
        self.type = 'undefined'
        if 'type' in recordingJson:
            self.type = recordingJson['type']
        if 'episodeTitle' in recordingJson:
            self.episodeTitle = recordingJson['episodeTitle']
        self.synopsis = ''
        if 'synopsis' in recordingJson:
            self.synopsis = recordingJson['synopsis']

        if 'captionLanguages' in recordingJson:
            for subtitle in recordingJson['captionLanguages']:
                self.subtitles.append(self.Language(subtitle))
        self.audioLanguages = []
        if 'audioLanguages' in recordingJson:
            for subtitle in recordingJson['audioLanguages']:
                self.audioLanguages.append(self.Language(subtitle))
        self.ottMarkers = []
        if 'ottMarkers' in recordingJson:
            self.ottMarkers = recordingJson['ottMarkers']
        self.channelId = None
        if 'channelId' in recordingJson:
            self.channelId = recordingJson['channelId']  # NL_000001_019401
        self.prePaddingOffset = recordingJson['prePaddingOffset']  # 300
        self.postPaddingOffset = recordingJson['postPaddingOffset']  # 900
        self.recordingType = recordingJson['recordingType']  # nDVR
        self.showId = None
        if 'showId' in recordingJson:
            self.showId = recordingJson['showId']  # crid:~~2F~~2Fgn.tv~~2F817615~~2FSH010806510000
        self.title = None
        if 'title' in recordingJson:
            self.title = recordingJson['title']
        self.startTime = recordingJson['startTime']  # 2024-01-17T11:00:00.000Z
        self.endTime = recordingJson['endTime']  # 2024-01-17T11:16:00.000Z
        self.source = recordingJson['source']  # single
        if 'id' in recordingJson:
            self.id = recordingJson['id']  # crid:~~2F~~2Fgn.tv~~2F817615~~2FSH010806510000~~2F237133469,
            # imi:517366be71fa5106c9215d9f1367cbacef4a4772
        else:
            self.id = recordingJson['episodeId']
        # self.type = recordingjson['type']  # single or season
        if 'ottPaddingsBlackout' in recordingJson:
            self.ottPaddingsBlackout = recordingJson['ottPaddingsBlackout']  # false
        else:
            if 'isOttBlackout' in recordingJson:
                self.ottPaddingsBlackout = recordingJson['isOttBlackout']  # false
        if 'isPremiereAirings' in recordingJson:
            self.isPremiereAirings = recordingJson['isPremiereAirings']  # false
        else:
            self.isPremiereAirings = False
        if 'deleteTime' in recordingJson:
            self.deleteTime = recordingJson['deleteTime']  # 2025-01-16T11:16:00.000Z
        else:
            self.deleteTime = recordingJson['expirationDate']  # ???
        if 'retentionPeriod' in recordingJson:
            self.retentionPeriod = recordingJson['retentionPeriod']  # 365
        else:
            self.retentionPeriod = 0
        if 'autoDeletionProtected' in recordingJson:
            self.autoDeletionProtected = recordingJson['autoDeletionProtected']  # false
        else:
            self.autoDeletionProtected = False
        self.isPremiere = recordingJson['isPremiere']  # false, true: when latest episode playing
        self.trickPlayControl = []
        if 'trickPlayControl' in recordingJson:
            self.trickPlayControl = recordingJson['trickPlayControl']
        if 'episodeNumber' in recordingJson:
            self.episodeNumber = recordingJson['episodeNumber']
        if 'seasonNumber' in recordingJson:
            self.seasonNumber = recordingJson['seasonNumber']

    @property
    def isRecording(self) -> bool:
        """
        Returns True if the state of the Recording is recording or ongoing
        @return: True/False
        """
        return self.recordingState in ['recording', 'ongoing']

    @property
    def isPlanned(self):
        """
        Returns True if the state of the Recording is planned
        @return: True/False
        """
        return self.recordingState == 'planned'

    @property
    def isRecorded(self):
        """
        Returns True if the state of the Recording is recorded
        @return: True/False
        """
        return self.recordingState == 'recorded'


class SeasonRecording:
    """
    class for season/series recording
    It is a container for recordings which belong to a series/season. It is not a single recording itself.
    The recordings itself are stored in the episodes attribute and can be of type PlannedRecording or SingleRecording
    """

    # pylint: disable=too-many-instance-attributes, too-few-public-methods
    def __init__(self, recordingJson, recordingtype:RecordingType):
        self.poster = Poster(posterJson=recordingJson['poster'])
        self.recordingtype = recordingtype
        self.title = recordingJson['title']
        self.source = recordingJson['source']
        self.nrofepisodes = recordingJson['noOfEpisodes']
        self.channelId = recordingJson['channelId']
        self.id = recordingJson['id']
        self.type = recordingJson['type']
        self.shortSynopsis = None
        if 'shortSynopsis' in recordingJson:
            self.shortSynopsis = recordingJson['shortSynopsis']
        self.genres = []
        if 'genres' in recordingJson:
            self.genres = recordingJson['genres']
        self.images = []
        if 'images' in recordingJson:
            self.images = recordingJson['images']
        self.seasons = []
        if 'seasons' in recordingJson:
            self.seasons = recordingJson['seasons']

        if self.type == 'season':
            self.seasonTitle = recordingJson['seasonTitle']
            self.showId = recordingJson['showId']
            self.minimumAge = 0
            if 'minimumAge' in recordingJson:
                self.minimumAge = recordingJson['minimumAge']
            self.diskSpace = 0
            if 'diskSpace' in recordingJson:
                self.diskSpace = recordingJson['diskSpace']
            self.isPremiereAirings = False
            if 'isPremiereAirings' in recordingJson:
                self.isPremiereAirings = recordingJson['isPremiereAirings']
            self.relevantEpisode = None
            if 'mostRelevantEpisode' in recordingJson:
                self.relevantEpisode = recordingJson['mostRelevantEpisode']
            self.episodes = []
            if 'episodes' in recordingJson:
                episodes = recordingJson['episodes']
                self.cnt = 0
                if 'total' in episodes:
                    self.cnt = episodes['total']
                self.episodes = []
                for episode in episodes['data']:
                    if episode['recordingState'] == 'planned':
                        recPlanned = PlannedRecording(episode, self)
                        self.episodes.append(recPlanned)
                    else:
                        recSingle = SingleRecording(episode, self)
                        self.episodes.append(recSingle)
        else:
            self.episodes = []
            self.showId = self.id

    def get_episodes(self, recType):
        """

        @param recType: one 'planned|recorded'
        @return: list of requested types
        """
        retList = []
        episode: Recording = None
        for episode in self.episodes:
            if recType == 'planned':
                if episode.recordingState == 'planned':
                    retList.append(episode)
            elif recType in ['recorded', 'ongoing']:
                if episode.recordingState != 'planned':
                    retList.append(episode)
        return retList


class SingleRecording(Recording):
    """
    class for a SingleRecording (not planned, not season).
    """

    # pylint: disable=too-many-instance-attributes
    def __init__(self, recordingJson, season: SeasonRecording = None):
        super().__init__(recordingJson)
        if 'privateCopy' in recordingJson:
            self.private = recordingJson['privateCopy']
        else:
            self.private = False
        self.isAdult = recordingJson['containsAdult']
        if '' in recordingJson:
            self.diskSpace = recordingJson['diskSpace']  # 0.041527778
        else:
            self.diskSpace = 0
        self.technicalDuration = recordingJson['technicalDuration']
        self.isOttBlackout = False
        if 'isOttBlackout' in recordingJson:
            self.isOttBlackout = recordingJson['isOttBlackout']  # false
        self.duration = recordingJson['duration']  # 598,
        self.bookmark = recordingJson['bookmark']  # 0
        self.viewState = recordingJson['viewState']  # notWatched
        self.season: SeasonRecording = season
        if self.season is not None:
            if self.channelId is None:
                self.channelId = self.season.channelId
            if self.showId is None:
                self.showId = self.season.showId
            if self.title is None:
                self.title = self.season.title


class PlannedRecording(Recording):
    """
    class for a planned recording (not a season or single recording).
    """

    def __init__(self, recordingJson, season: SeasonRecording = None):
        super().__init__(recordingJson)
        self.minimumAge = 0
        if 'minimumAge' in recordingJson:
            self.minimumAge = recordingJson['minimumAge']
        self.viewState = 'notWatched'
        self.season: SeasonRecording = season
        if season is not None:
            if self.channelId is None:
                self.channelId = self.season.channelId
            if self.showId is None:
                self.showId = self.season.showId
            if self.title is None:
                self.title = self.season.title


class RecordingList:
    """
    container class for a list of recordings of any type
    """
    # pylint: disable=too-few-public-methods
    def __init__(self, recordingsJson=None, recordingtype:RecordingType=None):
        self.recs = []
        if recordingsJson is None:
            self.total = 0
            self.size = 0
            self.quota = 0
            self.occupied = 0
            return

        self.total = recordingsJson['total']
        self.size = recordingsJson['size']
        self.quota = recordingsJson['quota']['quota']
        self.occupied = recordingsJson['quota']['occupied']
        for data in recordingsJson['data']:
            if data['type'] in ['season', 'show']:
                season = SeasonRecording(data, recordingtype)
                self.recs.append(season)
            elif data['type'] == 'single':
                if data['recordingState'] == 'planned':
                    recPlanned = PlannedRecording(data)
                    self.recs.append(recPlanned)
                else:
                    recSingle = SingleRecording(data)
                    self.recs.append(recSingle)

    def append(self, recordingsJson, recordingtype=RecordingType.PLANNED|RecordingType.RECORDED):
        """
        function to append recordings received in a webcall
        
        :param self: 
        :param recordingsJson: the received data containing recordings to append to the list
        :param recordingtype: type of recordings, can either planned or recorded
        """
        self.total += recordingsJson['total']
        self.size += recordingsJson['size']
        self.quota += recordingsJson['quota']['quota']
        self.occupied += recordingsJson['quota']['occupied']
        for data in recordingsJson['data']:
            if data['type'] in ['season', 'show']:
                season = SeasonRecording(data, recordingtype)
                self.recs.append(season)
            elif data['type'] == 'single':
                if data['recordingState'] == 'planned':
                    recPlanned = PlannedRecording(data)
                    self.recs.append(recPlanned)
                else:
                    recSingle = SingleRecording(data)
                    self.recs.append(recSingle)

    def find(self, eventId):
        """
        function to find a recording by its id
        @param eventId:
        @return: recording
        """
        for rec in self.recs:
            if isinstance(rec, SeasonRecording):
                season: SeasonRecording = rec
                for srec in season.episodes:
                    if srec.id == eventId:
                        return srec
            else:
                recording: Recording = rec
                if recording.id == eventId:
                    return rec
        return None

    def get_planned_recordings(self):
        """
        function to get all planned recordings
        @return: list of planned recordings
        """
        plannedRecs = []
        for rec in self.recs:
            if isinstance(rec, PlannedRecording):
                recording: PlannedRecording = rec
                if recording.isPlanned:
                    plannedRecs.append(recording)
        return plannedRecs

    def get_recorded_recordings(self):
        """
        function to get all recorded recordings
        @return: list of recorded recordings
        """
        recordedRecs = []
        for rec in self.recs:
            if isinstance(rec, SingleRecording):
                recording: SingleRecording = rec
                if recording.isRecorded:
                    recordedRecs.append(recording)
        return recordedRecs

    def get_all_recordings(self):
        """
        function to get all recordings
        @return: list of all recordings
        """
        allRecs = []
        for rec in self.recs:
            if isinstance(rec, SeasonRecording):
                season: SeasonRecording = rec
                for srec in season.episodes:
                    allRecs.append(srec)
            elif isinstance(rec, SingleRecording):
                recording: SingleRecording = rec
                allRecs.append(recording)
            elif isinstance(rec, PlannedRecording):
                recording: PlannedRecording = rec
                allRecs.append(recording)
        return allRecs

    def get_season_recordings(self):
        """
        function to get all season recordings, i.e. recordings of type SeasonRecording
        a season recording is a container for multiple recordings of a series/season
        @return: list of season recordings
        """
        seasonRecs = []
        for rec in self.recs:
            if isinstance(rec, SeasonRecording):
                season: SeasonRecording = rec
                seasonRecs.append(season)
        return seasonRecs

    def sort_listitems(self, listing: list, sortby: int, sortorder: int):
        """
        Function to sort a list of ListItems
        
        :param self: 
        :param listing: list of listitems
        :type listing: list
        :param sortby: the key to sort on
        :type sortby: int
        :param sortorder: the order in which to sort 
        :type sortorder: int
        """
        if int(sortby) == utils.SharedProperties.TEXTID_NAME:
            if int(sortorder) == utils.SharedProperties.TEXTID_ASCENDING:
                listing.sort(key=lambda x: x.getLabel().lower())
            else:
                listing.sort(key=lambda x: x.getLabel().lower(), reverse=True)
        elif int(sortby) == utils.SharedProperties.TEXTID_NUMBER:
            # We do not sort on number for recordings
            pass
        elif int(sortby) == utils.SharedProperties.TEXTID_DATE:
            if int(sortorder) == utils.SharedProperties.TEXTID_ASCENDING:
                listing.sort(key=lambda x: int(x.getVideoInfoTag().getUniqueID('ziggoRecordingId')))
            else:
                listing.sort(key=lambda x: int(x.getVideoInfoTag().getUniqueID('ziggoRecordingId')), reverse=True)

class SavedStateList:
    """
    class to keep the state of played recording. This is used to resume a recording at the point where
    playback was stopped the last time
    """

    def __init__(self, addon: xbmcaddon.Addon):
        self.addon = addon
        self.addonPath = xbmcvfs.translatePath(self.addon.getAddonInfo('profile'))
        self.states = {}
        self.fileName = self.addonPath + G.PLAYBACK_INFO
        targetdir = os.path.dirname(self.fileName)
        if targetdir == '':
            targetdir = os.getcwd()
        if not os.path.exists(targetdir):
            os.makedirs(targetdir)
        if not os.path.exists(self.fileName):
            with open(self.fileName, 'w', encoding='utf-8') as file:
                json.dump(self.states, file)
        self.__load()

    def __load(self):
        with open(self.fileName, 'r+', encoding='utf-8') as file:
            self.states = json.load(file)

    def add(self, itemId, position):
        """
        function to add/update the position of a recording
        @param itemId:
        @param position:
        @return:
        """
        self.states.update({itemId: {'position': position,
                                     'dateAdded': utils.DatetimeHelper.unix_datetime(datetime.datetime.now())}})
        with open(self.fileName, 'w', encoding='utf-8') as file:
            json.dump(self.states, file)

    def delete(self, itemId):
        """
        function to delete the recording from the state list
        @param itemId:
        @return:
        """
        if itemId in self.states:
            self.states.pop(itemId)

    def get(self, itemId):
        """
       function to find a recording by its id
       @param itemId:
       @return:
        """
        for item in self.states:
            if item == itemId:
                return self.states[item]['position']
        return None

    def cleanup(self, daysToKeep=365):
        """
        function to clean up saved recording states
        @param daysToKeep: 
        @return: 
        """
        expDate = datetime.datetime.now() - datetime.timedelta(days=daysToKeep)
        for item in list(self.states):
            if self.states[item]['dateAdded'] < utils.DatetimeHelper.unix_datetime(expDate):
                self.delete(item)
        with open(self.fileName, 'w', encoding='utf-8') as file:
            json.dump(self.states, file)
