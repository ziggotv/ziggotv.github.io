import unittest
import os
import json
import threading

import xbmcaddon

from resources.lib.globals import G
from resources.lib.servicemonitor import HttpProxyService
from resources.lib.webcalls import LoginSession


class TestBase(unittest.TestCase):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.cleanup_all()
        self.session = LoginSession(xbmcaddon.Addon())
        self.session.print_network_traffic = 'false'
        self.svc = HttpProxyService(threading.Lock())
        self.svc.set_address(('127.0.0.1', 6868))
        self.svc.startHttpServer()

    def setUp(self):
        print("Executing setup")

    def tearDown(self):
        self.svc.stopHttpServer()

    def remove(self, file):
        if os.path.exists(file):
            os.remove(file)

    def cleanup_cookies(self):
        self.remove(G.COOKIES_INFO)

    def cleanup_channels(self):
        self.remove(G.CHANNEL_INFO)

    def cleanup_customer(self):
        self.remove(G.CUSTOMER_INFO)

    def cleanup_session(self):
        self.remove(G.SESSION_INFO)

    def cleanup_entitlements(self):
        self.remove(G.ENTITLEMENTS_INFO)

    def cleanup_widevine(self):
        self.remove(G.WIDEVINE_LICENSE)
        self.remove(G.WIDEVINE_LICENSE + '.raw')

    def cleanup_all(self):
        self.cleanup_customer()
        self.cleanup_session()
        self.cleanup_channels()
        self.cleanup_cookies()
        self.cleanup_entitlements()
        self.cleanup_widevine()

    def do_login(self):
        with open(f'c:/temp/credentials.json', 'r') as credfile:
            credentials = json.loads(credfile.read())
        self.session.login(credentials['username'], credentials['password'])
