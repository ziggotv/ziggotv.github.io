from  resources.lib.webcalls import LoginSession
from resources.lib.utils import main
session: LoginSession
main()
